/* Corner Grocer
* Author: Jairo Figueroa Rojas
* Description:
* This program reads a text file addressing grocery items and shows the frequency of items in store/stock
* Also it has a menu option and it creates a backup file named "frequency.dat" that has the frequency number for each product
*/

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <limits>
#include <cctype>

using namespace std;

// Class for Grocery Tracker
class GroceryTracker {
private:
    map<string, int> freqByKey;           // Stores the product name and the number of times that product has been bought
    map<string, string> displayFor;      // Display original name

    // Helps to make searches case-insensitive
    static string ToLower(const string& s) {
        string out;
        for (char c : s) {
            out += static_cast<char>(tolower(static_cast<unsigned char>(c)));
        }
        return out;
    }

    // Allows for removal of any whitespaces or newlines for better reading
    static string Trim(const string& s) {
        size_t start = s.find_first_not_of(" \t\n\r");
        size_t end = s.find_last_not_of(" \t\n\r");
        if (start == string::npos) return "";
        return s.substr(start, end - start + 1);
    }

    // Adds product to the list and counts product frequency
    void AddItem(const string& rawItem) {
        string item = Trim(rawItem);     
        if (item.empty()) return;        

        string key = ToLower(item);      
        if (displayFor.find(key) == displayFor.end()) {
            displayFor[key] = item;      
        }
        ++freqByKey[key];                 // Increases the count for product
    }

public:
    // Reads the text file containing grocery products and detects the frequency for each product
    bool LoadFromFile(const string& path) {
        freqByKey.clear();
        displayFor.clear();

        ifstream inFile(path.c_str());
        if (!inFile) {
            return false; // If file not found
        }

        string line;
        while (getline(inFile, line)) {
            AddItem(line); // Reads the list of products
        }
        inFile.close();
        return true;
    }

    // Generates the backup file named "frequency.dat" that includes the frequency of each product
    bool WriteBackup(const string& path = "frequency.dat") const {
        ofstream outFile(path.c_str());
        if (!outFile) {
            return false;
        }

        vector<pair<string, int> > all = GetAllFrequencies();
        for (size_t i = 0; i < all.size(); ++i) {
            outFile << all[i].first << " " << all[i].second << endl;
        }

        outFile.close();
        return true;
    }

    // Calculate the amount of times a product repeats
    int GetFrequency(const string& item) const {
        string key = ToLower(Trim(item));
        map<string, int>::const_iterator it = freqByKey.find(key);
        if (it == freqByKey.end()) {
            return 0; // if product not found
        }
        return it->second;
    }

    // Returns all of the product counts
    vector<pair<string, int> > GetAllFrequencies() const {
        vector<pair<string, int> > list;
        for (map<string, int>::const_iterator it = freqByKey.begin(); it != freqByKey.end(); ++it) {
            string displayName = displayFor.at(it->first);
            list.push_back(make_pair(displayName, it->second));
        }

        // Organized by alphabetical order while still making sure it is case-insensitive
        sort(list.begin(), list.end(), [](const pair<string, int>& a, const pair<string, int>& b) {
            string al = a.first, bl = b.first;
            transform(al.begin(), al.end(), al.begin(), ::tolower);
            transform(bl.begin(), bl.end(), bl.begin(), ::tolower);
            return al < bl;
            });

        return list;
    }
};

//Menu Functions

// Displays the main menu
void PrintMenu() {
    cout << "\n***** Corner Grocer - Item Frequency Tracker *****\n";
    cout << "1. Look up frequency for a specific item\n";
    cout << "2. Print all item frequencies\n";
    cout << "3. Print histogram of item frequencies\n";
    cout << "4. Exit\n";
    cout << "Choose an option (1-4): ";
}

// Validates user's input 
int ReadMenuChoice() {
    int choice;
    while (true) {
        if (cin >> choice && choice >= 1 && choice <= 4) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            return choice;
        }
        cout << "Invalid input. Please enter a number (1 to 4): "; // display message if invalid input 
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

// Menu
int main() {
    const string inputPath = "CS210_Project_Three_Input_File.txt"; // Input file name
    GroceryTracker tracker; //Creates class instance

    // try to read file with product list
    if (!tracker.LoadFromFile(inputPath)) {
        cerr << "Error: Could not open '" << inputPath << "'.\n";
        cerr << "Make sure the file is in the same folder as the program.\n";
        return 1;
    }

    // Generate backup file frequency.dat
    if (!tracker.WriteBackup("frequency.dat")) {
        cerr << "Warning: Could not create 'frequency.dat'.\n";
    }

    // Loop for menu options
    bool running = true;
    while (running) {
        PrintMenu();
        int choice = ReadMenuChoice();

        switch (choice) {
        case 1: {
            // Menu Option 1: frequency
            cout << "Enter the item name to search: ";
            string query;
            getline(cin, query);
            int freq = tracker.GetFrequency(query);
            cout << query << " " << freq << endl;
            break;
        }
        case 2: {
            // Menu Option 2: Display all product frequencies
            vector<pair<string, int> > all = tracker.GetAllFrequencies();
            cout << "\n--- Item Frequencies ---\n";
            for (size_t i = 0; i < all.size(); ++i) {
                cout << all[i].first << " " << all[i].second << endl;
            }
            break;
        }
        case 3: {
            // Menu Option 3: Display histogram
            vector<pair<string, int> > all = tracker.GetAllFrequencies();
            cout << "\n--- Purchase Frequency Histogram ---\n";
            for (size_t i = 0; i < all.size(); ++i) {
                cout << all[i].first << " ";
                for (int k = 0; k < all[i].second; ++k) cout << "*";
                cout << endl;
            }
            break;
        }
        case 4:
            // Menu Option 4: Exit
            cout << "Goodbye!\n";
            running = false;
            break;
        }
    }

    return 0;
}